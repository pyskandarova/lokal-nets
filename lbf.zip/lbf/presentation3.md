---
## Front matter
lang: ru-RU
title: Администрирование локальных сетей
subtitle: Лабораторная 3
author:
  - Скандарова П.Ю.
institute:
  - Российский университет дружбы народов, Москва, Россия
date: 1 марта 2025

## i18n babel
babel-lang: russian
babel-otherlangs: english

## Formatting pdf
toc: false
toc-title: Содержание
slide_level: 2
aspectratio: 169
section-titles: true
theme: metropolis
header-includes:
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
---

# Информация

## Докладчик

:::::::::::::: {.columns align=center}
::: {.column width="70%"}

  * Скандарова Полина Юрьевна
  * студентка
  * Российский университет дружбы народов
  * [1132221815@pfur.ru](mailto:1132221815@pfur.ru)
  * <https://pyskandarova.github.io/ru/>

# Вводная часть

## Цели и задачи

- Познакомится с принципами планирования локальной сети организации.

# Выполнение задания

## Схема L1

:::
::: {.column width="30%"}

![](./lbf/Диаграмма1.png)

:::
::::::::::::::

## Схема L2

:::
::: {.column width="30%"}

![](./lbf/Диаграмма2.png)

:::
::::::::::::::

## Схема L3

:::
::: {.column width="30%"}

![](./lbf/Диаграмма3.png)

:::
::::::::::::::

## Таблица VLAN

:::
::: {.column width="30%"}

![](./lbf/1.png)

:::
::::::::::::::

## Таблица портов

:::
::: {.column width="30%"}

![](./lbf/3.png)

:::
::::::::::::::

## Таблица IP-адресов

:::
::: {.column width="30%"}

![](./lbf/2.png)

:::
::::::::::::::

# Результаты

## Вывод

- С принципами планирования локальной сети организации ознакомлена.

